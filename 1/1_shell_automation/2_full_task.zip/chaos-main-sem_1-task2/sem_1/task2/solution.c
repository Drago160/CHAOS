#include<stdio.h>

int toInt(char c)
{
	return c-'0';
}



int main()
{
	char* strings = "";
	int sum = 0;

	int i = 1;
	while (strings[i]){
		if (strings[i] == '@')
		{
			++i;
			continue;
		}
		if (strings[i+1] && strings[i+1] == '@') {
			printf("\n");
			++i;
		} else {
			printf("%c", strings[i]);
		}
		i++;
	}

	printf("\n%d", sum);

	return 0;
}



